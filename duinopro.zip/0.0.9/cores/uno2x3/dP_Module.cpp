/*
 * dP_Module.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Module.h>
#include <pins_arduino.h>


// 1x1 module constructor
dP_Module::dP_Module(int id)
  : _id(id)
  , _id2(0)    // no id2 for 1x1 module
	, _spiInterface(dP_Spi())
	, _i2cInterface(dP_Wire())
	, _spiSelect(dP_Pin(moduleSpiSelectToPin(_id)))
{
  if(_id == 4)
  {
    	_serialInterface = dP_Serial();
  }

	for (int i=0; i<GPIO_PINS_PER_MODULE; i++)
	{
		pinMap[i] = dP_Pin(_id, i+1);
	}
};

// 2x1 module constructor
dP_Module::dP_Module(int id, int id2)
  : _id(id)
  , _id2(id2)
	, _spiInterface(dP_Spi())
	, _i2cInterface(dP_Wire())
	, _spiSelect(dP_Pin(moduleSpiSelectToPin(min(_id,_id2))))
{
  if(max(_id,_id2) == 4)
  {
      _serialInterface = dP_Serial();
  }

  pinMap[0] = dP_Pin(min(_id,_id2), 1);
	for (int i=1; i<GPIO_PINS_PER_MODULE; i++)
	{
		pinMap[i] = dP_Pin(max(_id,_id2), i+1);
	}
};

/*int dP_Module::id()
{
    return _id;
}*/


void dP_Module::begin()
{
	//empty method; included for consistency with other module interfaces
}

    /**
     * Provides access to the Pins.
     */

dP_Pin& dP_Module::pin(uint8_t pin)
{
    return (pinMap[pin-1]);
};

uint8_t dP_Module::digitalPin(uint8_t modulePin)
{
    return moduleSignalToPin(_id, modulePin);
}


dP_Pin& dP_Module::spiSelect()
{
    return _spiSelect;
};

dP_Spi& dP_Module::spi()
{
    return _spiInterface;
};

dP_Wire& dP_Module::wire()
{
    return _i2cInterface;
};

dP_Serial& dP_Module::serial()
{
    // 1x1 Module
    if(_id2 == 0)
    {
      if(_id == 4)
      {
        return _serialInterface;
      }
      else
      {
        // DEBUG
        Serial.print("Attempting to use serial port in a non-serial space.\n");
      }
    }
    else  //2x1 Module
    {
      if(max(_id,_id2) == 4)
      {
        return _serialInterface;
      }
      else
      {
        // DEBUG
        Serial.print("Attempting to use serial port in a non-serial space.\n");
      }
    }
}

    /* TODO:  Interrupts */
