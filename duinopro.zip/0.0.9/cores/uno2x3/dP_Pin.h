/*
 * dP_Pin.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DP_PIN_H
#define DP_PIN_H

#include <Arduino.h>

/**
 * The Pin class encapsulates everything you can do with a pin.
 */
class dP_Pin {
    private:
        uint8_t _id;

	public:
	    // Set pinMode values from constants in Arduino.h, to ensure consistency.
        enum pinMode {
            PIN_INPUT = INPUT,
			      PIN_OUTPUT = OUTPUT,
            PIN_INPUT_PULL_UP = INPUT_PULLUP,
        };


		/**
		 * Constructor that makes a NOT_A_PIN.
		 */
		dP_Pin();
		/**
		 * Constructor that takes the wiring_digital 'pin' id as an argument.
		 */
		dP_Pin(uint8_t id);

		/**
		 * Constructor that takes the module position number and pin on module as arguments.
		 */
		dP_Pin(uint8_t mod, uint8_t pin);

		/**
         * Set whether the pin is going to be used for input
         * or out, as well setting pull ups.
         */
        void mode(uint8_t value);

        /**
         * For a pin that is has the mode OUTPUT, change its
         * value.
         */
        void write(bool value);

        /**
         * Read back the value of a pin. Works for any mode.
         */
        bool read(void);
};


#endif /* DP_PIN_H */
