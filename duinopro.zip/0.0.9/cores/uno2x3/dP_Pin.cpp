/*
 * dP_Pin.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Pin.h>
#include <Arduino.h>
#include <pins_arduino.h>


dP_Pin::dP_Pin()
{
	_id = NOT_A_PIN;
};

dP_Pin::dP_Pin(uint8_t id)
{
	_id = id;
};

dP_Pin::dP_Pin(uint8_t mod, uint8_t pin)
{
	_id = moduleSignalToPin(mod, pin);
};

void dP_Pin::mode(uint8_t value)
{
	::pinMode(_id, value);
 };

void dP_Pin::write(bool value)
{
	::digitalWrite(_id, value);
};

bool dP_Pin::read(void)
{
	return ::digitalRead(_id);
};
