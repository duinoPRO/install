/*
 * dP_Serial.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DP_SERIAL_H
#define DP_SERIAL_H

#include <arduino.h>


class dP_Serial {
    private:


    protected:


    public:

		  dP_Serial();

      void begin(unsigned long baud);

      int available(void);

      size_t write(uint8_t data);
      size_t write(unsigned long data);
      size_t write(long data);
      size_t write(unsigned int data);
      size_t write(int data);
      size_t write(const char *str);
      size_t write(const uint8_t *buff, size_t size);

      int read(void);
      int peek(void);
      String readStringUntil(char terminator);
};

#endif /* DP_SERIAL_H */
