/*
 * dP_Module.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DP_MODULE_H
#define DP_MODULE_H


#include <dP_Pin.h>
#include <dP_Spi.h>
#include <dP_Wire.h>
#include <dP_Serial.h>


#define GPIO_PINS_PER_MODULE    6


class dP_Module {
    private:
	    int _id;
      int _id2;
		  dP_Pin pinMap[GPIO_PINS_PER_MODULE];
		  dP_Pin _spiSelect;
      dP_Spi _spiInterface;
      dP_Wire _i2cInterface;
      dP_Serial _serialInterface;

    protected:
		    int id();

    public:
		// static Pin *pinMap[NUM_MODULES+1][GPIO_PINS_PER_MODULE+1];
		// static Pin *spiSelectMap[NUM_MODULES+1];

		  dP_Module(int id);
      dP_Module(int id, int id2);

      /** \brief Begin using the dP_Module module.
      */
      void begin(void);

		  // void initialisePinMap();
		  /**
		  * Provides access to the Pins.
		  */
		  dP_Pin& pin(uint8_t pin);

		  // Gets the digital pin number, for the relevant module pin
		  uint8_t digitalPin(uint8_t modulePin);

      // SPI interface
		  dP_Pin& spiSelect();
      dP_Spi& spi();

      //I2C interface
      dP_Wire& wire();

      //Serial (USART) interface
      dP_Serial& serial();

		  /* TODO:  Interrupts */
};

#endif /* DP_MODULE_H */
