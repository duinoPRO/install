/*
 * dP_Expander.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Expander.h>
#include <Wire.h>
#include <pins_arduino.h>

#define EXPANDER_I2C_ADDR 0x20
#define expanderPinToConfigId(p)    (((p) & 0x7F) - 1)

void expanderPinMode(uint8_t pin, uint8_t mode)
{
    uint8_t modeCode;
    uint8_t pin_id;
    pin_id = expanderPinToConfigId(pin);

    if (mode==OUTPUT)
    {
        modeCode = 0;
    }
    else
    {
        modeCode = 1;
    }
    //address the pin
    Wire.beginTransmission(EXPANDER_I2C_ADDR);
    Wire.write(0x18 + pin_id / 8);
    Wire.endTransmission();
    //read in current value
    Wire.requestFrom(EXPANDER_I2C_ADDR, 1);
    uint8_t old_value = Wire.read();
    //adjust to new value
    bitWrite(old_value, pin_id % 8, modeCode);
    //write out over I2C
    Wire.beginTransmission(EXPANDER_I2C_ADDR);
    Wire.write(0x18 + pin_id / 8);
    Wire.write(old_value);
    Wire.endTransmission();
}

void expanderWrite(uint8_t pin, uint8_t val)
{
    uint8_t pin_id;
    pin_id = expanderPinToConfigId(pin);

    //address the pin
    Wire.beginTransmission(EXPANDER_I2C_ADDR);
    Wire.write(0x08 + pin_id / 8);
    Wire.endTransmission();
    //read in current value
    Wire.requestFrom(EXPANDER_I2C_ADDR, 1);
    uint8_t old_value = Wire.read();
    //adjust to new value
    bitWrite(old_value, pin_id % 8, val);
    //write out over I2C
    Wire.beginTransmission(EXPANDER_I2C_ADDR);
    Wire.write(0x08 + pin_id / 8);
    Wire.write(old_value);
    Wire.endTransmission();
}

int expanderRead(uint8_t pin)
{
	uint8_t pin_id;
    pin_id = expanderPinToConfigId(pin);

	//address the pin
    Wire.beginTransmission(EXPANDER_I2C_ADDR);
    Wire.write(0x00 + pin_id / 8);
    Wire.endTransmission();
    //read in current value
    Wire.requestFrom(EXPANDER_I2C_ADDR, 1);
    return bitRead(Wire.read(), pin_id % 8);
}
