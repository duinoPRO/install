/*
 * duinoPRO.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <duinoPRO.h>
#include <pins_arduino.h>
#include <Arduino.h>
#include <avr/sleep.h>

// Setup
duinoPRO::duinoPRO(void)
{
	pinMode(VBAT_SENSE_EN_PIN, OUTPUT);
	digitalWrite(VBAT_SENSE_EN_PIN, LOW);

	pinMode(BASEBOARD_LED, OUTPUT);
	digitalWrite(BASEBOARD_LED, LOW);

	pinMode(UART_SELECT_PIN, OUTPUT);
	digitalWrite(UART_SELECT_PIN, HIGH);
};

// Battery measurement
void duinoPRO::enableVbatSense()
{
	digitalWrite(VBAT_SENSE_EN_PIN, true);
}

void duinoPRO::disableVbatSense()
{
	digitalWrite(VBAT_SENSE_EN_PIN, false);
}

float duinoPRO::getVbat()
{
    int vbatRaw = analogRead(VBAT);
    return (vbatRaw * (3.3/1023.0) * (10750.0/750.0));
}

// baseboard "ON" LED
void duinoPRO::setLed(bool on)
{
    digitalWrite(BASEBOARD_LED, on);
}

// serial port control
void duinoPRO::serialDebugMode()
{
	Serial.flush();
	digitalWrite(UART_SELECT_PIN, HIGH);
}

void duinoPRO::serialModuleMode()
{
	Serial.flush();
	digitalWrite(UART_SELECT_PIN, LOW);
}

// Sleep modes
void duinoPRO::enableSleepMode(SleepMode mode)
{
	switch(mode)
	{
		case SLEEP_MODE_IDLE:
			set_sleep_mode(SLEEP_MODE_IDLE);
			break;
		case SLEEP_MODE_ADC:
			set_sleep_mode(SLEEP_MODE_ADC);
			break;
		case SLEEP_MODE_PWR_DOWN:
			set_sleep_mode(SLEEP_MODE_PWR_DOWN);
			break;
		case SLEEP_MODE_PWR_SAVE:
			set_sleep_mode(SLEEP_MODE_PWR_SAVE);
			break;
		case SLEEP_MODE_STANDBY:
			set_sleep_mode(SLEEP_MODE_STANDBY);
			break;
	}

	sleep_enable();
}
