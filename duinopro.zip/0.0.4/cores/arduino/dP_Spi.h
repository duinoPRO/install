/*
 * dP_Spi.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DP_SPI_H
#define DP_SPI_H


#include <SPI.h>


class dP_Spi {
    private:

      static bool _spiInitialised;

    protected:


    public:

		  dP_Spi();

      /** \brief Begin using the dP_Spi interface.
      */
      void begin(void);

      void beginTransaction(uint32_t clock, uint8_t bitOrder, uint8_t dataMode);

      uint8_t transfer(uint8_t data);
      void transfer(void *buf, size_t count);

      uint16_t transfer16(uint16_t data);

      void endTransaction(void);
};

#endif /* DP_SPI_H */
