/*
 * duinoPRO.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DUINOPRO_H
#define DUINOPRO_H

//export dP_Module.h and dP_Pin.h
#include <dP_Module.h>
#include <dP_Pin.h>


class duinoPRO {
    private:

    protected:
    //    Pin *vbatSenseEnPin;
	//    Pin *vbatSensePin;

    public:
      enum SleepMode
      {
          SLEEP_MODE_IDLE,
          SLEEP_MODE_ADC,
          SLEEP_MODE_PWR_DOWN,
          SLEEP_MODE_PWR_SAVE,
          SLEEP_MODE_STDBY
      };

     	duinoPRO(void);

    	void enableVbatSense();
      void disableVbatSense();
    	float getVbat();

      void setLed(bool on);

    	void serialDebugMode();
    	void serialModuleMode();

      void enableSleepMode(SleepMode mode);
};

#endif /* DUINOPRO_H */
