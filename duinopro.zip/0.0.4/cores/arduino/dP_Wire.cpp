/*
 * dP_Wire.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Wire.h>


dP_Wire::dP_Wire()
{
};


/* wrapper methods around standard I2C interface for MCU */
void dP_Wire::beginTransmission(uint8_t address)
{
  Wire.beginTransmission(address);
}


size_t dP_Wire::write(uint8_t data)
{
  return Wire.write(data);
}


size_t dP_Wire::write(unsigned long data)
{
  return Wire.write(data);
}


size_t dP_Wire::write(long data)
{
  return Wire.write(data);
}


size_t dP_Wire::write(unsigned int data)
{
  return Wire.write(data);
}


size_t dP_Wire::write(int data)
{
  return Wire.write(data);
}


uint8_t dP_Wire::endTransmission(void)
{
  return Wire.endTransmission();
}


uint8_t dP_Wire::requestFrom(uint8_t address, uint8_t quantity)
{
  return Wire.requestFrom(address, quantity);
}


int dP_Wire::read(void)
{
  return Wire.read();
}
