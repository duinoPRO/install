/*
 * dP_Serial.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Serial.h>


dP_Serial::dP_Serial()
{
};

/* wrapper methods around standard Serial interface for MCU */
void dP_Serial::begin(unsigned long baud)
{
  Serial.begin(baud);
}


int dP_Serial::available(void)
{
  return Serial.available();
}


size_t dP_Serial::write(uint8_t data)
{
  return Serial.write(data);
}


size_t dP_Serial::write(unsigned long data)
{
  return Serial.write(data);
}


size_t dP_Serial::write(long data)
{
  return Serial.write(data);
}


size_t dP_Serial::write(unsigned int data)
{
  return Serial.write(data);
}


size_t dP_Serial::write(int data)
{
  return Serial.write(data);
}


size_t dP_Serial::write(const char *str)
{
  return Serial.write(str);
}


size_t dP_Serial::write(const uint8_t *buff, size_t size)
{
  return Serial.write(buff, size);
}

int dP_Serial::read(void)
{
  return Serial.read();
}


int dP_Serial::peek(void)
{
  return Serial.peek();
}


String dP_Serial::readStringUntil(char terminator)
{
  return Serial.readStringUntil(terminator);
}
