/*
 * dP_Spi.cpp is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#include <dP_Spi.h>


dP_Spi::dP_Spi()
{
};

/* wrapper methods around standard SPI interface for MCU */
void dP_Spi::begin()
{
	if (!dP_Spi::_spiInitialised)
	{
		SPI.begin();
		dP_Spi::_spiInitialised = true;
	}
}

bool dP_Spi::_spiInitialised = false;


void dP_Spi::beginTransaction(uint32_t clock, uint8_t bitOrder, uint8_t dataMode)
{
  SPI.beginTransaction(SPISettings(clock, bitOrder, dataMode));
}

uint8_t dP_Spi::transfer(uint8_t data)
{
  return SPI.transfer(data);
}


void dP_Spi::transfer(void *buf, size_t count)
{
	SPI.transfer(buf, count);
}


uint16_t dP_Spi::transfer16(uint16_t data)
{
	return SPI.transfer16(data);
}


void dP_Spi::endTransaction(void)
{
  SPI.endTransaction();
}
