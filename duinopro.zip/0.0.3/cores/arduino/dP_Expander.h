/*
 * dP_Expander.h is part of the duinoPRO firmware.
 *
 * duinoPRO is an Arduino™-compatible platform in a flat form factor with surface-mount,
 * solderable modules. It is designed with commercialization of real products in mind.
 * Note that we have designed duinoPRO to be compatible with the Arduino™ IDE.  This does
 * not imply that duinoPRO is certified, tested or endorsed by Arduino™ in any way.
 *
 * For more information, contact info@duinopro.cc or visit www.duinopro.cc.
 *
 * This file is licensed under the BSD 3-Clause license
 * (see https://github.com/duinoPRO/firmware/blob/master/duinoPRO_BSD_fwlicense.txt).
 *
 * Using duinoPRO core and libraries licensed under BSD for the firmware of a commercial
 * product does not require you to release the source code for the firmware.
 *
*/

#ifndef DP_EXPANDER_H
#define DP_EXPANDER_H

#include "Arduino.h"

#ifdef __cplusplus
extern "C"{
#endif

void expanderPinMode(uint8_t pin, uint8_t mode);
void expanderWrite(uint8_t pin, uint8_t val);
int expanderRead(uint8_t pin);

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* DP_EXPANDER_H */
