
// #include <../../libraries/Wire/Wire.h>
#include <Wire.h>
// #include <../../libraries/SPI/SPI.h>
#include <Arduino.h>
#include <pins_arduino.h>

void initVariant() 
{ 
	Wire.begin();
	pinMode(EXPANDER_RSTN, OUTPUT);
	digitalWrite(EXPANDER_RSTN, LOW);
	delay(10);
	digitalWrite(EXPANDER_RSTN, HIGH);

	// Configure SPI Pins, and start SPI
	/*
    pinMode(SS, OUTPUT);
    pinMode(SCK, OUTPUT);
    pinMode(MOSI, OUTPUT);
	SPI.begin();
	*/
	delay(10);
}